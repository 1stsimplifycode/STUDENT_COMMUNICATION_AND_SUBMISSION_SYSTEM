
import discord
from config import DISCORD_BOT_TOKEN

intents = discord.Intents.default()
client = discord.Client(intents=intents)

async def send_discord(user_id, message):
    user = await client.fetch_user(user_id)
    await user.send(message)
