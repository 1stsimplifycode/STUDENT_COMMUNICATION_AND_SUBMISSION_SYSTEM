
from telegram import Bot
from config import TELEGRAM_BOT_TOKEN

bot = Bot(token=TELEGRAM_BOT_TOKEN)

def send_telegram(chat_id, message):
    bot.send_message(chat_id=chat_id, text=message)
