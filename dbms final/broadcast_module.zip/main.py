
from channels import telegram, discord, email

students = [
    {'name':'Alice','telegram_id':'123','discord_id':'456','email':'alice@example.com','preferred_channel':'telegram'},
    {'name':'Bob','telegram_id':'789','discord_id':'012','email':'bob@example.com','preferred_channel':'discord'},
    {'name':'Carol','telegram_id':'345','discord_id':'678','email':'carol@example.com','preferred_channel':'email'},
]

message = "CS101 Announcement: Submit Assignment 2 via LMS. Contact: prof@college.edu"

for student in students:
    if 'telegram' in student['preferred_channel']:
        telegram.send_telegram(student['telegram_id'], message)
    if 'discord' in student['preferred_channel']:
        # discord sending requires async run
        import asyncio
        asyncio.run(discord.send_discord(student['discord_id'], message))
    if 'email' in student['preferred_channel']:
        email.send_email(student['email'], "CS101 Announcement", message)
