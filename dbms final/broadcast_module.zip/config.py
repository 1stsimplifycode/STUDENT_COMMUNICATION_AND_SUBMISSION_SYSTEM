
# config.py
TELEGRAM_BOT_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN'
DISCORD_BOT_TOKEN = 'YOUR_DISCORD_BOT_TOKEN'
EMAIL_HOST = 'smtp.example.com'
EMAIL_PORT = 587
EMAIL_USER = 'your_email@example.com'
EMAIL_PASS = 'your_email_password'
